# app/main.py
import os
import time
from app.parser import parse_resume
from app.scorer import score_resume
from app.emailer import send_feedback_email
from app.utils import setup_logging, log_to_csv
from app.config import RESUME_FOLDER

def process_resume(file_path, logger):
    """एक रिज्यूम फाइल को प्रोसेस करता है"""
    logger.info(f"Processing resume: {os.path.basename(file_path)}")
    
    # रिज्यूम पार्स करें
    resume_data, error = parse_resume(file_path)
    if error:
        logger.error(f"Failed to parse resume: {error}")
        return False
    
    logger.info(f"Successfully parsed resume for: {resume_data['name']}")
    
    # रिज्यूम स्कोर करें
    score_data = score_resume(resume_data)
    logger.info(f"Resume scored: {score_data['total_score']}/100")
  # app/main.py (continued)
    # फीडबैक ईमेल भेजें
    email_status = send_feedback_email(resume_data, score_data)
    if email_status[0]:
        logger.info(f"Email sent successfully to {resume_data['email']}")
    else:
        logger.error(f"Failed to send email: {email_status[1]}")
    
    # रिज़ल्ट्स को CSV में लॉग करें
    log_to_csv(resume_data, score_data, email_status)
    
    return True

def main():
    """मेन एप्लिकेशन एंट्री पॉइंट"""
    # लॉगिंग सेटअप करें
    logger = setup_logging()
    logger.info("CV Scoring System started")
    
    # रेज्यूमे फोल्डर चेक करें
    if not os.path.exists(RESUME_FOLDER):
        logger.error(f"Resume folder not found: {RESUME_FOLDER}")
        return
    
    # सभी रेज्यूमे फाइल्स चेक करें
    resume_files = [f for f in os.listdir(RESUME_FOLDER) 
                   if f.lower().endswith(('.pdf', '.docx'))]
    
    if not resume_files:
        logger.warning(f"No resume files found in {RESUME_FOLDER}")
        return
    
    logger.info(f"Found {len(resume_files)} resume files to process")
    
    # सभी रेज्यूमे प्रोसेस करें
    processed = 0
    for resume_file in resume_files:
        file_path = os.path.join(RESUME_FOLDER, resume_file)
        
        if process_resume(file_path, logger):
            processed += 1
        
        # थोड़ा पॉज़ लें (ईमेल सर्वर लिमिट्स के लिए)
        time.sleep(1)
    
    logger.info(f"Processing complete. {processed}/{len(resume_files)} resumes processed.")

if __name__ == "__main__":
    main()


