def send_feedback_email(to_email, name, score_dict):
    # format email using template
    # send via SMTP securely
Hello {name},

Thank you for submitting your resume.

Here’s your score:
- Education: {education}
- Skills: {skills}
...
